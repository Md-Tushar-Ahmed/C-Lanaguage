#include <stdio.h>
#include<stdlib.h>
struct Node{
int data;
struct Node *Link;
};
struct Node *head;
void print()
{
struct Node *temp;
temp=head;
while(temp != NULL){
printf("%d ",temp->data);
temp=temp->Link;
}
printf("\n");
}
void insert(int value)
{
struct Node* temp=(struct Node*)malloc(sizeof(struct Node));
temp->data=value;
temp->Link=NULL;
if(head==NULL){
head=temp;
}
else {
struct Node *t;
t=head;
while(t->Link != NULL){
t=t->Link;
}
t->Link=temp;
}
}
int main()
{
head=NULL;
insert(1);
insert(4);
insert(3);
insert(5);
insert(7);
print();
return 0;
}
