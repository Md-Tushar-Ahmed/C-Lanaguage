#include<stdio.h>
int main()
{

    int n;
    //n=rand()%10+1;
    for(int i=1;i<=10;i++){
            n=rand()%10+1;
         printf("%d\n",n);
    }

    return 0;
}
