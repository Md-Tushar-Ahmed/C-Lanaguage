#include<stdio.h>
int main()
{
    int n;
    int i=1;
    scanf("%d",&n);
   while(i<=n)
   {
       if((i%3==0) && (i%5==0) && (i%7==0))
       {
           printf("%d\n",i);
       }
       i++;
   }
    return 0;
}
