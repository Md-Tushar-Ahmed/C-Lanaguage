#include<stdio.h>
int main()
{
    int A[10][10],B[10][10],C[10][10],i,j,numberOfRow,numberOfCol;
    printf("Enter the number of rows and col:");
    scanf("%d %d",&numberOfRow,&numberOfCol);

    printf("Enter elements of A matrix.\n");

    for(i=0;i<numberOfRow;i++)
    {
        for(j=0;j<numberOfCol;j++)
        {
            printf("A[%d][%d]=",i,j);
            scanf("%d",&A[i][j]);
        }
        printf("\n");
    }
     printf("Enter elements of B matrix.\n");

    for(i=0;i<numberOfRow;i++)
    {
        for(j=0;j<numberOfCol;j++)
        {
            printf("B[%d][%d]=",i,j);
            scanf("%d",&B[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<numberOfRow;i++)
    {
        for(j=0;j<numberOfCol;j++)
        {
            C[i][j]=A[i][j]+B[i][j];
        }
        printf("\n");
    }
    printf("\nC=A+B=");
    for(i=0;i<numberOfRow;i++)
    {
        printf("\t");
        for(j=0;j<numberOfCol;j++)
        {
            printf("%d ",C[i][j]);
        }
        printf("\n");
    }
    return 0;


}
