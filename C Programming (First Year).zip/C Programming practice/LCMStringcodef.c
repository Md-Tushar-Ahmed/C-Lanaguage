#include <stdio.h>
#include <string.h>
int main()
{
    int t;
    scanf("%d", &t);
    while (t--)
    {
        int flag = 0;
        char a1[200], a2[200], b1[200], b2[200];
        scanf("%s %s", a1, b1);
        strcpy(a2, a1);
        strcpy(b2, b1);
        while (1)
        {
            if (strcmp(a2, b2) == 0)
            {
                flag = 1;
                break;
            }
            else if (strlen(a2) == strlen(b2))
            {
                flag = -1;
                break;
            }
            else if (strlen(a2) < strlen(b2))
                strcat(a2, a1);
            else if (strlen(a2) > strlen(b2))
                strcat(b2, b1);
        }
        if (flag == -1)
            printf("-1\n");
        else
            printf("%s\n", a2);
    }
    return 0;
}