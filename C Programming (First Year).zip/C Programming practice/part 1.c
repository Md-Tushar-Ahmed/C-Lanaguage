#include<stdio.h>
void makeArray(int n)
{
    int i,arr[n];
    printf("Enter the Elements of Array:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
        arr[i]=arr[i]*i;
    }
    printf("The Elements of Array:\n");
    for(i=0;i<n;i++)
    {
        printf("%d\n",arr[i]);
    }
}
int main()
{
    makeArray(4);
    return 0;
}
