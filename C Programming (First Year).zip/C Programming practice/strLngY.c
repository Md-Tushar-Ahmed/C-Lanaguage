#include<stdio.h>
int main()
{
    int i,length=0;
    char arr[]={"My name is Tushar"};
    puts(arr);

    for(i=0;i<arr[i] != '\0';i++)
    {
        length++;

    }
    printf("The length of the array:%d",length);
    return 0;

}
