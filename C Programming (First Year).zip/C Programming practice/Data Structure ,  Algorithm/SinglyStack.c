#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node*next;
};
struct  Node*top = 0;

void push(int x)
{
    struct  Node*newnode;

    newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = x;
    newnode->next = top;
    top = newnode;
}

void display()
{
    struct Node*temp;
    temp = top;
    if( top == 0){
        printf("The stack list is Empty\n\n");
    }
    else{
        while( temp != 0){
            printf("%d ",temp->data);
            temp = temp->next;
        }
        
    }
    printf("\n");
}

void peek()
{
    if(top == 0){
        printf("Stack is empty\n");
    }
    else{
        printf("Top element is %d ",top->data);
    }
}

void pop()
{
    struct Node*temp;
    temp = top;
    if(top == 0){
        printf("Stack is empty\n");
    }
    else{
        printf("%d ",top->data);
        top = top->next;
    }
}

void main()
{
    push(2);
    push(3);
    push(5);
    display();
    peek(5);
    display();
    pop(2);
    display();
    peek(3);
    display();

}
