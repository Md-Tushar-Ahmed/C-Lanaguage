#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<dos.h>
int main()
{
    int a,row,c,m=3,n,temp;
    //textcolor(MAGENDA+BLINK);
    //gotoxy(30,3);
    //delay(500);
    printf("***TUSHAR AHMED***\n");
    getch();
    //nosound();
    //textcolor(RED+BLINK):
    //gotoxy(28,5);
    printf("HAPPY NEW YEAR 2021\n");
    getch();
    //textcolor(RED+BLINK);
    //gotoxy(18,9);
    printf("IN THE NEW YEAR 2021 MAY YOU BE BLEASED\n");
    //gotoxy(25,11);
    printf("With All the Good things....\n");
    getch();
    //textcolor(YELLOW+BLINK);
    printf("\n\n");
    temp = m*12;
    for(row=1; row<=m; row++)
    {
        for(c=1; c<temp; c++)
            printf(" ");
        temp--;
        for(c=1; c<=2*row-1; c++)
            printf("*\n");

    }
    getch();
}
