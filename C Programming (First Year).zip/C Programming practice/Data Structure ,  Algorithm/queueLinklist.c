#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node*next;
};
struct Node*front = NULL;
struct Node*rear = NULL;
void enqueue(int x)
{
    struct Node*newnode;
    newnode=(struct Node*)malloc(sizeof(struct Node));
    newnode->data=x;
    newnode->next=NULL;
    if(front==NULL && rear==NULL){
        front=rear=newnode;
    }
    else{
        rear->next=newnode;
        rear=newnode;
    }
}

void dequeue()
{
    struct Node*temp;
    temp=front;
    if(front == NULL && rear==NULL){
        printf("Empty\n");
    }
    else{
        printf("%d ",front->data);
        front=front->next;
        free(temp);
    }
}

void peek()
{
    if(front==NULL && rear==NULL){
        printf("Empty\n");
    }
    else{
        printf("%d ", front->data);
    }
}
void display()
{
    struct Node*temp;
    if(front==NULL && rear==NULL){
        printf("The queue is Empty\n");
    }
    else{
        temp=front;
        while(temp!=NULL){
            printf("%d ",temp->data);
            temp=temp->next;
        }
    }
}
int main()
{
    printf("Enqueue :\n");
    enqueue(10);
    enqueue(20);
    enqueue(30);
    display();
    printf("\nDequeue :\n");
    dequeue();
    printf("\nPeek : \n");
    peek();
}