#include <stdio.h>
#include <stdlib.h>
struct node
{
    int data;
    struct node*next;
};
struct node*head,*tail;

void insert(int value)
{
    struct node*newnode;
    head = NULL;
    newnode = (struct node*)malloc(sizeof(struct node));
    newnode->data = value;
    newnode->next = NULL;
    if(head == NULL)
    {
        head = tail;
        tail = newnode;
        //tail->next=head;
    }
    else
    {
        tail->next=newnode;
        tail=newnode;
        //tail->next=head;
    }
    tail->next=head;
}
void print()
{
    struct node*temp;
    temp = head;
    if (temp == NULL)
    {
        printf("The list is Empty\n");
    }
    else
    {
        //temp = head;
        while (temp != NULL)
        {
            printf("%d ", temp->data);
            temp = temp->next;
        }
        printf("\n");
    }
}
int main()
{
    head = NULL;
    insert(1);
    //print();
    insert(3);
    //print();
    insert(5);
    //print();
    insert(7);
    //print();
    insert(9);

    print();
}
