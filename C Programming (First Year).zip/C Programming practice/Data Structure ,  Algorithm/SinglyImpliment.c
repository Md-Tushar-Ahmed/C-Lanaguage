#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node*next;
};
struct Node*head=NULL,*newnode,*temp;
void insert(int value)
{
    struct Node*newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->next = NULL;
    if(head==NULL)
    {
        head=temp=newnode;
    }
    else
    {
        temp->next=newnode;
        temp=newnode;

    }

}
void display()
{
    struct Node *temp;
    temp=head;
    while(temp != NULL)
    {
        printf("%d\n",temp->data);
        temp=temp->next;
    }
    printf("\n");
}
int main()
{
    printf("Implement of Singly Linked List : \n");
    insert(2);
    insert(3);
    insert(4);
    insert(5);
    display();
    return 0;
}