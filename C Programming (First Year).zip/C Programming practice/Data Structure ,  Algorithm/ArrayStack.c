#include<stdio.h>
#define CAPACITY 3
int stack[CAPACITY];
int top = -1;

void push(int x)
{
    if(top < CAPACITY - 1){
        top = top+1;
        stack[top] = x;
        printf("Successfully added item %d\n",x);
    }
    else{
        printf("No spaces\n");
    }

}
int main()
{
    printf("Implimentation Stack in C.\n");
    push(10);
    push(20);
    push(30);
    return 0;
}
