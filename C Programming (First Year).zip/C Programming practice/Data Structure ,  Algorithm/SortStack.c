// C program to sort a stack using recursion 
#include <stdio.h> 
#include <stdlib.h> 


struct stack { 
	int data; 
	struct stack* next; 
}; 


void initStack(struct stack** head) { *head = NULL; } 


int isEmpty(struct stack* head) 
{ 
	if (head == NULL) 
		return 1; 
	return 0; 
} 


void push(struct stack** head, int x) 
{ 
	struct stack* p = (struct stack*)malloc(sizeof(*p)); 

	if (p == NULL) { 
		printf(stderr, "Memory allocation failed.\n"); 
		return; 
	} 

	p->data = x; 
	p->next = *head; 
	*head = p; 
} 

 
int pop(struct stack** head) 
{ 
	int x; 
	struct stack* temp; 

	x = (*head)->data; 
	temp = *head; 
	(*head) = (*head)->next; 
	free(temp); 

	return x; 
} 

 
int top(struct stack* head) { return (head->data); } 

 
void sortedInsert(struct stack** head, int x) 
{ 
	
	if (isEmpty(*head) || x > top(*head)) { 
		push(head, x); 
		return; 
	} 

	 
	int temp = pop(head); 
	sortedInsert(head, x); 

	
	push(head, temp); 
} 

 
void sortStack(struct stack** head) 
{ 
	 
	if (isEmpty(*head) == NULL) { 
		 
		int x = pop(head); 

	
		sortStack(head); 
 
		sortedInsert(head, x); 
	} 
} 
 
void printStack(struct stack* head) 
{ 
	while (head) { 
		printf("%d  ", head->data); 
		head = head->next; 
	} 
	printf("\n"); 
} 

 
int main() 
{ 
	struct stack* top; 

	initStack(&top); 
	push(&top, 30); 
	push(&top, 25); 
	push(&top, 20); 
	push(&top, 15); 
	push(&top, 10); 

	printf("Stack elements before sorting:\n"); 
	printStack(top); 

	sortStack(&top); 
	printf("\n"); 

	printf("Stack elements after sorting:\n"); 
	printStack(top); 

	return 0; 
}

