#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *prev;
    struct Node *next;
};
struct Node *head, *tail=NULL;
void insert(int value)
{
    struct Node *newnode;
    //head = NULL;
    newnode = (struct Node *)malloc(sizeof(struct Node));
    newnode->prev = NULL;
    newnode->data = value;
    newnode->next = NULL;
    if (head == NULL)
    {
        head = tail = newnode;
        //tail = tail->next;
        // head->next = head;
        // head->prev = head;
    }
    else
    {
        tail->next = newnode;
        newnode->prev = tail;
        newnode->next = head;
        head->prev = newnode;
        tail = newnode;
    }
}
void display()
{
    struct Node *temp = head;
    if (head == NULL)
    {
        printf("The list is Empty\n");
    }
    else
    {
        do
        {
            printf("%d ", temp->data);
            temp = temp->next;
        } while(temp != head);
        printf("\n");
    }
}
int main()
{
    head = NULL;
    printf("Doubly circular Link list Implementation:\n");
    insert(1);
    insert(2);
    insert(3);
    insert(5);
    insert(10);
    display();
}
