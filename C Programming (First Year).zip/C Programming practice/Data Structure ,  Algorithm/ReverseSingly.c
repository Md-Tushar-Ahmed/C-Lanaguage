#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node*next;
};
struct Node*head=NULL,*temp;
void insert(int value)
{
    struct Node*newnode=(struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->next = NULL;
    if(head == NULL)
    {
        head=temp=newnode;
    }
    else
    {
        temp->next = newnode;
        temp = newnode;
    }
}

void Reverse()
{
    struct Node*prev,*curr,*nextnode;
    prev = NULL;
    curr = nextnode = head;
    while(nextnode != NULL)
    {
        nextnode = nextnode->next;
        curr->next = prev;
        prev = curr;
        curr = nextnode;
    }
    head = prev;
}
void display()
{
    struct Node*temp;
    temp = head;
    while(temp != NULL)
    {
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

int main()
{
    printf("Insertion Elements : \n");
    insert(1);
    insert(3);
    insert(5);
    insert(7);
    display();
    printf("Reverse Elements : \n");
    Reverse();
    display();
    return 0;
}