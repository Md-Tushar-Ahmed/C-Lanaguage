#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *next;
} * tail;
void push(int value)
{
    struct Node *newnode = (struct Node *)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->next = NULL;
    if (tail == NULL)
    {
        printf("The list is Empty\n");
    }
    else
    {
        newnode->next = tail->next;
        tail->next = newnode;
    }
}
void reverse()
{
    struct Node *prev, *curr, *nextnode;
    curr = tail->next;
    nextnode = curr->next;
    if (tail == NULL)
    {
        printf("The list is invalid\n");
    }
    else
    {
        while (curr != tail)
        {
            prev = curr;
            curr = nextnode;
            nextnode = curr->next;
            curr->next = prev;
        }
        nextnode->next = tail;
        tail = nextnode;
    }
}
void display()
{
    struct Node *temp;
    temp = tail;
    if (tail == NULL)
    {
        printf("The list is Empty\n");
    }
    else
    {
        do
        {
            printf("%d ", temp->data);
            temp = temp->next;
        } while (temp != temp);
        printf("\n");
    }
}
int main()
{

    struct Node *tail = NULL;
    push(2);
    push(4);
    push(8);
    push(10);
    printf("\n Original Linked list ");
    display();
    printf("\n Reversed Linked list ");
    reverse();
    display();
}