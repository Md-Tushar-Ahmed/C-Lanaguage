//haacckkerrannkk = hackerrank
#include<stdio.h>
#include<string.h>
int main()
{

    int i,j,n,flag=0;
    char s[1000],a[10]="hackerrank";
    scanf("%d",&n);
    for(int k=0;k<n;k++){
            flag=0;
            j=0;

        scanf("%s",s);
        for(i=0;i<10;i++){

            while(s[j]!='\0'){
                if(a[i]==s[j]){
                    flag++;
                    j++;
                    break;
                }
                else
                    j++;
            }
        }
        if(flag==10) printf("YES\n");
        else printf("NO\n");
    }

    return 0;
}
