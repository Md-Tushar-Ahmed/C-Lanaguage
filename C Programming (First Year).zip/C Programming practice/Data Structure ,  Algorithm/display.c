#include <stdio.h>
#include <time.h>

void sleep_now(const int sec) {
    time_t rawtime;
    time(&rawtime);
    int next_time = localtime(&rawtime)->tm_sec + sec;
    while(1) {
        time_t r_time;
        time(&r_time);
        if(localtime(&r_time)->tm_sec == next_time) break;
    }
    return;
}

int main () {
    int i;
    for(i=0; i<5; i++) {
        printf("Hello World\n");
        sleep_now(2); // sleep for 2 sec
    }

   return 0;
}

