#include <stdio.h>
#include <string.h>
int main()
{
    int i, j;
    int n;
    scanf("%d", &n);
    char str[52][52], sol[52][52];
    for (i = 0; i < n; i++)
    {
        scanf("%s", str[i]);
    }
    int max = 0;
    for (i = 0; i < n; i++)
    {
        if (strlen(str[i]) > max)
        {
            max = strlen(str[i]);
        }
    }
    for (i = 0; i < n; i++)
    {
        int gap = max - strlen(str[i]);
        int j = 0;
        while (gap--)
        {
            sol[i][j] = ' ';
            j++;
        }
        for (int k = 0; k < strlen(str[i]); k++)
        {
            sol[i][j] = str[i][k]; 
            j++;
        }
        sol[i][j] = '\0';
    }
    for (i = 0; i < n; i++)
    {
        printf("%s\n", sol[i]);
    }
    return 0;
}