// Singly circular linked list all
#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node*next;
}*tail;

void delete_at(int,int);
void delete_last(int);
void delete_first(int);

void insert_first(int value)
{
  struct Node*newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->next = NULL;
    if(tail == NULL)
    {
        tail=newnode;
        tail->next=newnode;
    }
    else{
        newnode->next=tail->next;
        tail->next=newnode;
    }
}
void insert_last(int value)
{
  struct Node*newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->next = NULL;
    if(tail == NULL)
    {
        tail=newnode;
        tail->next=newnode;
    }
    else{
        newnode->next=tail->next;
        tail->next=newnode;
        tail=newnode;
    }
}
void insert_at(int pos,int value)
{
     int i=1;
    if(pos==1){
        insert_first(value);
    }
    else{
        struct Node*newnode,*temp=tail;
        newnode=(struct Node*)malloc(sizeof(struct Node));
        newnode->data=value;
        while(i<pos-1){
            temp=temp->next;
            i++;
        }
        newnode->next=temp->next;
        temp->next=newnode;

}
}
void print()
{
    struct Node*temp;
    temp = tail;
    if (temp == NULL)
    {
        printf("The list is Empty\n");
    }
    else
    {

        // while (temp != NULL)
        // {
        //     printf("%d ", temp->data);
        //     temp = temp->next;
        // }
        do {
            printf("%d ",temp->data);
            temp = temp->next;
        } while(temp != temp);
        printf("\n");
    }
}

int main()
{

    //insert_first(1);

    insert_first(2);
    insert_at(2,9);
    //insert_first(3);
    insert_first(8);
    insert_last(4);
    insert_last(5);
    //insert_last(6);
    delete_first(1);
    delete_last(4);
    delete_at(3,8);
    print();

    return 0;
}
void delete_first(int value)
{
    struct Node*temp;
    temp=tail->next;
    if(tail==NULL){
        printf("The list is Empty\n");
    }
    else if(temp->next==temp){
        tail=NULL;
        free(temp);
    }
    else{
        tail->next=temp->next;
        free(temp);
    }
}
void delete_last(int value)
{
    struct Node*curr,*prev;
    curr=tail->next;
    if(tail==NULL){
        printf("The list is Empty\n");
    }
    else if(curr->next==curr){
        tail=NULL;
        free(curr);

    }
    else{
        while(curr->next != tail->next){
            prev=curr;
            curr=curr->next;

        }
        prev->next=tail->next;
        tail=prev;
        free(curr);
    }
}
void delete_at(int pos,int value)
{
    struct Node*curr,*nextnode;
    int i;
    curr=tail->next;
     if(pos==1){
        delete_first(value);
     }
     else{
        while(i<pos-1){
            curr=curr->next;
            i++;
        }
        nextnode=curr->next;
        curr->next=nextnode->next;
        free(nextnode);
     }
}
