#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node*left;
    struct Node*right;
};
struct Node*root;
void insert(int value)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->right = NULL;
    newnode->left = NULL;

    if (root == NULL)
    {
        root = newnode;
    }
    else
    {
        struct Node*temp = root;
        while(1)
        {
            if(newnode->data <= temp->data)
            {
                //left
                if(temp->left == NULL)
                {
                    temp->left = newnode;
                    break;
                }
                else
                {
                    temp = temp->left;
                }
            }
            else
            {
                //right
                 if(temp->right == NULL)
                {
                    temp->right = newnode;
                    break;
                }
                else
                {
                    temp = temp->right;
                }

            }
        }
    }
}

void preorder(struct Node*r)
{
    if(r == NULL)
    return;
    printf("%d\n",r->data);
    preorder(r->left);
    preorder(r->right);

}

void inorder(struct Node*r)
{
     if(r == NULL)
    return;
    inorder(r->left);
    printf("%d\n",r->data);
    inorder(r->right);
}

void postOrder(struct Node*r)
{
     if(r == NULL)
    return;
    postOrder(r->left);
    postOrder(r->right);
    printf("%d\n",r->data);
}


void main()
{

    root=NULL;

    insert(11);
    insert(22);
    insert(33);
    insert(44);
    insert(55);
    insert(66);
    printf("Preorder Display:\n");
    preorder(root);
    printf("Inorder Display:\n");
    inorder(root);
    printf("Postorder Display:\n");
    postOrder(root);

}
