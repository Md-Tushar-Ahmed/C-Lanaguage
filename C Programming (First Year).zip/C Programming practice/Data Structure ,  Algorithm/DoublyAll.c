#include <stdio.h>
#include <stdlib.h>

struct Node
{
    int data;
    struct Node *prev;
    struct Node *next;
} *head, *tail;
void insert_first(int value)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->next = NULL;
    newnode->prev = NULL;
    if(head == NULL)
    {

        head = newnode;
        tail = head;
    }
    else
    {
        head->prev=newnode;
        newnode->next=head;
        head=newnode;
    }
}
void insert_last(int value)
{
    struct Node *newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->next = NULL;
    newnode->prev = NULL;
    if(head == NULL)
    {

        head = newnode;
        tail = head;
    }
    else
    {
        tail->next=newnode;
        newnode->prev=tail;
        tail=newnode;
    }
}
void insert_at(int pos,int value)
{
    int i=1;
    if(pos==1){
        insert_first(value);
    }
    else{
        struct Node*newnode,*temp=head;
        newnode=(struct Node*)malloc(sizeof(struct Node));
        newnode->data=value;
        while(i<pos-1){
            temp=temp->next;
            i++;
        }
        newnode->prev=temp;
        newnode->next=temp->next;
        temp->next=newnode;
        newnode->next->prev=newnode;

    }
}
void display()
{
    struct Node *temp = head;
    do
    {
        printf("%d ",temp->data);
        temp = temp->next;
    }
    while(temp);
    printf("\n");
}
int main()
{

    insert_first(1);

    insert_first(2);
    insert_at(2,9);
    insert_first(3);
    insert_last(4);
    insert_last(5);
    insert_last(6);
    display();

    return 0;
}
