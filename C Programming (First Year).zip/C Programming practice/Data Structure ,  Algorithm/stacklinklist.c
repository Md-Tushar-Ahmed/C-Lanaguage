#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *link;
};
struct Node *top = 0;

void push(int value)
{
    struct Node *newnode = (struct Node *)malloc(sizeof(struct Node));
    newnode->data = value;
    newnode->link = top;
    top = newnode;
}

void peek()
{
    if (top == NULL)
    {
        printf("The stack is Empty\n");
    }
    else
    {
        printf("\nTop of the stack %d ", top->data);
    }
}

void pop()
{
    struct Node *temp;
    temp = top;
    if (top == NULL)
    {
        printf("There is no list in the stack");
    }
    else
    {
        printf("\nPop element is %d ", top->data);
        top = top->link;
        free(temp);
    }
}
void display()
{
    struct Node *temp;
    temp = top;
    if (top == NULL)
    {
        printf("The stack of link list is Empty\n");
    }
    else
    {
        while (temp != NULL)
        {
            printf("%d ", temp->data);
            temp = temp->link;
        }
        //printf("\n");
    }
}

void main()
{
    printf("Implement of stack of Link List : ");
    push(10);
    push(20);
    push(30);
    push(40);
    display();
    peek();
    pop();
    peek();
    printf("\n");
    display();
}