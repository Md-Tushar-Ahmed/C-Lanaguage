#include<stdio.h>
#include<stdbool.h>
#define CAPACITY 5
int ourQueue[CAPACITY];
int front=0,rear=-1,totalItem=0;
bool isFull(){
    if(totalItem==CAPACITY){
        return true;
    }
    return false;
}
bool isEmpty(){
    if(totalItem==0){
        return true;
    }
    return false;
}
void enqueue(int x){
    if(isFull()){
        printf("Sorry, The List is Full\n");
        return;
    }
    rear=(rear+1)%CAPACITY;
    ourQueue[rear]=x;
    totalItem++;

}
void dequeue(){
    if(isEmpty()){
        printf("Sorry ! Queue is Empty\n");
        return false;
    }
    
    int frontItem=ourQueue[front];
    ourQueue[front]=-1;
    front=(front+1)%CAPACITY;
    totalItem--;
    return frontItem;
}
void printQueue(){
    int i;
    for(i=0;i<CAPACITY;i++){
        printf("%d ",ourQueue[i]);
    }
    printf("\n");
}
int main()
{
    printf("Implementation of Array of Queue:\n");
    enqueue(10);
    enqueue(15);
    enqueue(20);
    enqueue(25);
    enqueue(30);
    printQueue();
    enqueue(35);
    dequeue();
    printQueue();
    enqueue(40);
    printQueue();

}