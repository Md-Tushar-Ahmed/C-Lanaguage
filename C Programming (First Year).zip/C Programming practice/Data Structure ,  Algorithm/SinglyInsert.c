#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node*next;
};
struct Node*head=NULL,*newnode,*temp;
void insert_first(int value)
{
    struct Node*newnode=(struct Node*)malloc(sizeof(struct Node));
    newnode->data=value;
    newnode->next=NULL;
    if(head==NULL)
    {
        head=temp=newnode;
    }
    else
    {
        newnode->next = head;
        head = newnode;
    }
}
void insert_last(int value)
{
    struct Node*newnode=(struct Node*)malloc(sizeof(struct Node));
    newnode->data=value;
    newnode->next=NULL;
    if(head == NULL)
    {
        head = temp = newnode;
    }
    else
    {
        temp->next = newnode;
        temp = newnode;
    }
}

void insert_at(int pos, int value)
{
    struct Node*fast = head,*slow = NULL,*newnode = (struct Node*)malloc(sizeof(struct Node));
    newnode->data = value;

    int counter = 1;
    while(counter < pos && fast != NULL)
    {
        slow = fast;
        fast = fast->next;
        counter++;
    }
    slow->next = newnode;
    newnode->next = fast;
}

void display()
{

    struct Node *temp;
    temp=head;
    while(temp != NULL)
    {
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("\n");
}
int main()
{
    insert_last(12);
    insert_first(1);
    insert_first(2);
    insert_first(3);
    insert_last(5);
    insert_at(3,99);
    display();

    return 0;
}
