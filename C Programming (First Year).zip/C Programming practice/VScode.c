#include<stdio.h>
#include<stdlib.h>
struct Node{
    int data;
    struct Node*next;
};
struct Node*head=NULL,*tail=NULL,*current;
void push(int value){
    struct Node*newnode=(struct Node*)malloc(sizeof(struct Node));
    newnode->data=value;
    newnode->next=NULL;
    if(head==NULL){
       head=tail;
       tail=newnode;

    }
    else{
       tail->next=newnode;
       tail=newnode;
        
    }
}
int classSolution()
{
    if(head==NULL || tail==NULL)
            return head;
    
    current=head;
    while(current->next != NULL){
        if(current->data == current->next->data){
            current->next=current->next->next;
        }
        else{
            current=current->next;
        }
        return head;
    }
    
}
void display()
{
    struct Node*temp;
     
    temp = head;
    if (head == NULL)
    {
        printf("The list is Empty\n");
    }
    else
    {
        do
        {
            printf("%d ", temp->data);
            temp = temp->next;
        } while (temp != NULL);
        printf("\n");
    }
}
int main()
{
    push(1);
    push(2);
    push(2);
    push(3);
    
    classSolution();
    display();
}