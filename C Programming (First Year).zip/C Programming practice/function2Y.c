#include<stdio.h>
float result(float h,float b)
{
    return 0.5*h*b;
}
int main()
{
    float height,base,area;
    printf("Enter two values:");
    scanf("%f %f",&height,&base);
    area=result(height,base);
    printf("Result of the Triangle:%f\n",area);
}
