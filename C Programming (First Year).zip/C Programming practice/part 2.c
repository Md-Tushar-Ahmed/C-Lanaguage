#include<stdio.h>
int rec_value(int value)
{
    if(value==1)
        return 1;
    return value-rec_value(value-1);
}
int main()
{
    int result,n;
    scanf("%d",&n);
    result=rec_value(n);
    printf("%d",result);
}
