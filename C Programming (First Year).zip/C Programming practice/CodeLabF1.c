#include <stdio.h>
#include <stdlib.h>
typedef struct Node Node;
struct Node {
int data;
Node *previous;
Node *next;
} *head = NULL , *last = NULL;
int length() {
Node *temp = head;
int count = 0;
do {
count++;
temp = temp->next;
} while(temp != head);
return count;
}
void insert_first(int value) {
Node *newNode = (Node*)malloc(sizeof(struct Node));
newNode->data = value;
newNode->next = NULL;
newNode->previous = NULL;
if(head == NULL) {
// first node creation complete
head = newNode;
last = head;
} else {
// after first node creation
// linking between nodes
newNode->next = head;
head->previous = newNode;
// create circle
newNode->previous = last;
last->next = newNode;
head = newNode; // setting newnode as head
}
}
void insert_last(int value) {
Node *newNode = (Node*)malloc(sizeof(struct Node));
newNode->data = value;
newNode->next = NULL;
newNode->previous = NULL;
if(head == NULL) {
// first node
head = newNode;
last = head;
} else {
// not first node
// linking
last->next = newNode;
newNode->previous = last;
// create circle
newNode->next = head;
head->previous = newNode;
last = newNode; // newNode as last
}
}
void insert_at(int pos, int value) {
int i;
Node *slow = NULL, *fast = head;
if(pos == 1) {
// provided position is first
insert_first(value);
} else if(pos == length() + 1) {
// provided position is last
insert_last(value);
} else if(pos > 1 && (pos < length() + 1)) {
// second to last-1 position
Node *newNode = (Node*)malloc(sizeof(struct Node));
newNode->data = value;
newNode->next = NULL;
newNode->previous = NULL;
for(i=1; i<pos; i++) {
slow = fast;
fast = fast->next;
}
slow->next = newNode;
newNode->previous = slow;
newNode->next = fast;
fast->previous = newNode;
} else return;
}
void delete_first() {
Node *temp = head; // assing the head to temp variable for deletion
head = head->next; // update head by next
free(temp); // for heap memory
// update circle linker
head->previous = last;
last->next = head;
}
void delete_last() {
Node *temp = last;
last = last->previous;
free(temp);
// update circle linker
head->previous = last;
last->next = head;
}
void delete_at(int pos) {
int i;
Node *slow = NULL, *fast = head, *temp = NULL;
if(pos == 1) {
delete_first();
} else if(pos == length()) {
delete_last();
} else if(pos > 1 && (pos < length())) {
for(i=0; i<pos; i++) {
slow = fast;
fast = fast->next;
}
temp = slow;
slow = slow->previous;
free(temp);
// linking again slow and fast
slow->next = fast;
fast->previous = slow;
} else return;
}
void display() {
Node *temp = head;
do {
printf("%d ",temp->data);
temp = temp->next;
} while(temp != head);
printf("\n");
}
void reverse_display() {
Node *temp = head->previous;
do {
printf("%d ",temp->data);
temp = temp->previous;
} while(temp != head->previous);
printf("\n");
}
void main() {
insert_first(100);
insert_first(10);
insert_last(20);
insert_at(2,55);
display();
reverse_display();
delete_first();
delete_last();
delete_at(2);
display();
reverse_display();
}
