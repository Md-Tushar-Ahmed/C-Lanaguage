#include<stdio.h>

 void factorial(int n)

{
 int i,fact=1,factorial;
  for(i=1;i<=n;i++)
    {
        factorial=fact*i;
           printf("%d",factorial);
    }


}
int main()
{
    int n;
    printf("Enter any positive num:");
    scanf("%d",&n);
    factorial(n);
}


