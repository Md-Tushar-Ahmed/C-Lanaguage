#include<stdio.h>
int main()
{
    float result;
    printf("Enter Numeric range:");
    scanf("%f",&result);
    if(result>80 && result<=100)
    {
        printf("The gpa is A+\n");
    }
    else if(result>75 && result<=80)
    {
        printf("The gpa is A\n");
    }
    else if(result>70 && result<=75)
    {
        printf("The gpa is A-\n");
    }
    else if(result>65 && result<=70)
    {
        printf("The gpa is B+\n");
    }
    else if(result>60 && result<=65)
    {
        printf("The gpa is B\n");
    }
    else if(result>=55 && result<=60)
    {
        printf("The gpa is B-\n");
    }
    else if(result>50 && result<=55)
    {
        printf("The gpa is C+\n");
    }
    else if(result>45 && result<=55)
    {
        printf("The gpa is C\n");
    }
    else if(result>40 && result<=45)
    {
        printf("The gpa is D\n");
    }
    else
    {
        printf("The gpa is F\n");
    }

    return 0;
}
