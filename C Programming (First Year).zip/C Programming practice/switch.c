#include<stdio.h>
int main()
{
    int x;

    switch(x=2)
    {
   case 1:
        printf("My name is Tushar\n",x);
        break;
        case 2:
    printf("I am a student\n",x);
        break;
        case 3:
            printf("I have a laptop\n",x);
        break;
        default:
            printf("I want to be an Engineer\n");

    }
    return 0;
}
