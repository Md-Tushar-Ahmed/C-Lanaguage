#include<stdio.h>
int main()
{
    int n, i;
    printf("Enter the size of the array: ", n);
    scanf("%d", &n);
    int array[100], sum=0, pro=1;
    printf("Enter the elements of the array: ");
    for(i=0; i<n; i++)
        scanf("%d", &array[i]);
    if(n/2 == 0)
    {
        for(i=0; i<n; i++)
            sum = sum + array[i];
        printf("Result = %d\n", sum);
    }
    else
    {
        for(i=0; i<n; i++)
            pro = pro * array[i];
        printf("Result = %d\n", pro);
    }
    return 0;
}
