#include<stdio.h>
int main()
{
    int input;
    printf("Enter the input: ");
    scanf("%d",&input);
    if (input>=10)
    {
        printf("%d is greater than 10",input);
    }
    else
    {
        printf("%d is less than 10",input);
    }
    return 0;
}
