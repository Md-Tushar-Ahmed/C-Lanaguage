#include<conio.h>
#include<stdio.h>
#include<process.h>
struct student{
     int rollno;
     char name[50];
     int p_marks,c_marks,m_marks,e_marks,cs_marks;
     float per;
     char grade;
     int std;
}st;
FILE *fptr;
void write_student()
{
    fptr=fopen("student.dat","ab");
    printf("\nPlease Enter the new details of students:\n");
    printf("\nEnter the Roll no of student: ");
    scanf("%d",&st.rollno);
    fflush(stdin);
    printf("Enter the Name of student: ");
    gets(st.name);
    printf("Enter the marks of physics out of 100: ");
    scanf("%d",&st.p_marks);
    printf("Enter the marks of chemistry out of 100: ");
    scanf("%d",&st.c_marks);
    printf("Enter the marks of Mathematics out of 100: ");
    scanf("%d",&m_marks);
    printf("Enter the marks of English out of 100: ");
    scanf("%d",&e_marks);
    printf("Enter the marks of Computer science out of 100: ");
    scanf("%d",&cs_marks);
    st.per=(st.p_marks+st.c_marks+st.m_marks+st.e_marks+st.cs_marks)/5.0;
    if(st.per>=60)
        st.grade='A';
    else if(st.per>=50 && st.per<60)
        st.grade='B';
    else if(st.per>=40 && st.per<50)
        st.grade='C';
    else
        st.grade='F';
    printf("\nMarks in physics: %d\n",p_marks);
    printf("\nMarks in Chemistry: %d\n",c_marks);
     printf("\nMarks in Mathematics: %d\n",m_marks);
      printf("\nMarks in English: %d\n",e_marks);
       printf("\nMarks in Computer Science: %d\n",cs_marks);
       printf("\nPercentage of student is: %.2f\n",st.per);
       printf("\nGrade of student is: %c\n",st.grade);
       flag=1;
       fclose(fptr);
       if(flag==0)
        printf("\n\nRecord not exist");
       return 0;
}
void modify_student()
{
    int no,found=0;
    clrscr();
    printf("\n\n\tTo Modify");
    printf("\n\n\tRoll number of student:");
    scanf("%d",&no);

}
