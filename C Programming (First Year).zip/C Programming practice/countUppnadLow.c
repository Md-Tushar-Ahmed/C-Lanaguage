#include<stdio.h>
int main()
{
    int upper=0,lower=0;
    char ch[80];
    int i;
    printf("Enter the string:");
    gets(ch);
    i=0;
    while(ch[i]!='\0')
    {
        //upper case counter
        if(ch[i]>='A' && ch[i]<='Z')
        {
            upper++;
        }

    //lower case counter
    if(ch[i]>='a' && ch[i]<='z')
    {
        lower++;
    }
    i++;
    }
    printf("\nuppercase letters:%d",upper);
    printf("\nlowercase letters:%d",lower);
    return 0;

}

