#include<stdio.h>//Sub Array Division
int main()
{
    int i,j,m,d,sum=0,n,p=0;
    int arr[n];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
        scanf("%d %d",&d,&m);

    }

    for(i=0;i<n;i++)
    {
        sum=0;
        for(j=0;j<m;j++)
        sum=sum+arr[i+j];
        if(sum==d)
        p++;
    }

    printf("%d",p);
    return 0;
}
