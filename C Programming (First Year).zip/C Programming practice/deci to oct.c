#include<stdio.h>
int main()
{
    int number;
    printf("Enter the decimal number:");
    scanf("%d",&number);


    printf("The octal number is %o",number);
    return 0;



}
