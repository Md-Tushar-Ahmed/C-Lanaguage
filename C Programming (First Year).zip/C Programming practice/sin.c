#include<stdio.h>
#include<math.h>
int main()
{
    double x=0.5;
    double result =sin(x);
    printf("sin(%lf)=%lf\n ",x,result);
    return 0;
}
