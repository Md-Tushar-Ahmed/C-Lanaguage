#include<stdio.h>
void increament(int var)
{
    var=var+1;
    printf("VALUE:%d",var);
}
int main()
{
    int num;
    printf("Enter the number:");
    scanf("%d",&num);
    increament(num);
}
