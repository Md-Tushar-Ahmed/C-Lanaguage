#include<stdio.h>
int main()
{
    char s1[50];
    printf("Enter your name:");
    gets(s1);
    printf("Full name=%s\n",s1);
    return 0;

}
