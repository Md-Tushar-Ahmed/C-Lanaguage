#include<stdio.h>
#include<stdlib.h>

int x = 200;
int *get_val(int y){
x+=y;
return &x;
}
int main()
{
int *p, y=10;
 //struct Node *p=NULL;
    //*p -> 400;
     int a;
    //a=(int p*)malloc(sizeof(int));
//p = get_val(y);
//printf("%d\n",*p);
//exit(0);
}

struct Node{

int *p;
};







