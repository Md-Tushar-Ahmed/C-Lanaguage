#include<stdio.h>
int main()
{
    int n,i,j,ft=0,fth=0,ff=0,ffv=0;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&j);
        if(j%2==0) ft++;
        if(j%3==0) fth++;
        if(j%4==0) ff++;
        if(j%5==0) ffv++;
    }
    printf("%d Multiplo(s) de 2\n",ft);
    printf("%d Multiplo(s) de 3\n",fth);
    printf("%d Multiplo(s) de 4\n",ff);
    printf("%d Multiplo(s) de 5\n",ffv);
    return 0;
}
