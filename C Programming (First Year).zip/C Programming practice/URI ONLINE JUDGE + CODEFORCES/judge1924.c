#include<stdio.h>//Vit�ria and Her Indecision
#include<string.h>
int main()
{
    int i,m;
    char ch[101];
    while(scanf("%d",&m)!=EOF) {
        getchar();//Why ??
        for(i=0;i<m;i++) {
            gets(ch);

        }
        printf("Ciencia da Computacao\n");
    }
    return 0;
}
