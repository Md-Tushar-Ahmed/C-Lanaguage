
{
printf("%d ", node->data);
node = node->next;
}