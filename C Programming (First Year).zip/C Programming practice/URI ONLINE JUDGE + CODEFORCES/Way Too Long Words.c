#include<stdio.h>
#include<string.h>
int main()
{
    int len,x;
    scanf("%d",&x);
    char str[101];
    while (x--)
    {
        scanf("%s",str);
        len = strlen(str);
        if(len <= 10)
              printf("%s\n",str);
        else
              printf("%c%d%c",str[0],len-2,str[len-1]);
    }
    return 0;
    
}