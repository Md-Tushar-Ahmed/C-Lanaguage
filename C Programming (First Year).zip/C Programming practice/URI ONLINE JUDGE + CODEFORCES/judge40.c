#include<stdio.h>
int main()
{
    float a,b,c,d,avg1,avg2,f;
    scanf("%f %f %f %f", &a, &b, &c, &d);
    a = a*2;
    b = b*3;
    c = c*4;
    d = d*1;
    avg1 = (a+b+c+d)/10;
    if(avg1>=7)
        printf("Media: %.1f\nAluno aprovado.\n",avg1);
    else if(avg1<5)
        printf("Media: %.1f\nAluno reprovado.\n",avg1);
    else if(avg1>=5 && avg1<7)
    {
        printf("Media: %.1f\nAluno em exame.\n",avg1);
        scanf("%f",&f);
        printf("Nota do exame: %.1f\n",f);
            avg2 = (avg1 + f) / 2;
            if(avg2>=5)
            {
                printf("Aluno aprovado.\n");
            }
            else
            {
                printf("Aluno reprovado.\n");
            }
            printf("Media final: %.1f\n",avg2);

    }
    return 0;

}
