#include<stdio.h>
#include<string.h>
int main()
{

    char str[501];
    int l;
    gets(str);
    l=strlen(str);
    if(l<=140){
        printf("TWEET\n");
    }
    else{
        printf("MUTE\n");
    }
    return 0;

}
