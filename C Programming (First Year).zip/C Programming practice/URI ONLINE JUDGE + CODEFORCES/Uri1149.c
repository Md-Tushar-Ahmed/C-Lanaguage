#include <stdio.h>
int main()
{
    int i, n, a, sum = 0;
    scanf("%d %d", &a, &n);
    while (n < 0 || n == 0)
        scanf("%d %d", &n);
    for (i = 0; i < n; i++)
    {
        sum = sum + a + i;
    }
    printf("%d\n", sum);
    return 0;
}