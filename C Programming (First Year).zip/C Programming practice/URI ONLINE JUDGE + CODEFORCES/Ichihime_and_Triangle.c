#include<stdio.h>
int main()
{
    int t;
    int a,b,c,d;

    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d %d %d",&a,&b,&c,&d);
        printf("%d %d %d\n",b,b,c);

    }
    return 0;
}