#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    int n;
    for(int i=0;i<t;i++)
    {
        scanf("%d",&n);
        for(int i=2;i<10e9;i++)
        {
            int p = pow(2,i)-1;
            if(n%p==0)
            {
                int a=n/p;
                printf("%d\n",a);
                break;
            }
        }
    }
    return 0;
}
