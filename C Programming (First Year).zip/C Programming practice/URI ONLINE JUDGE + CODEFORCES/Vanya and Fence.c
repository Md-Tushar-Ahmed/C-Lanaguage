#include<stdio.h>
int main()
{
    int t,h;
    int count=0;
    scanf("%d %d",&t,&h);
    int arr[t];
    for(int i=0;i<t;i++)
    {
        scanf("%d",&arr[i]);
        if(arr[i]<=h)
            count+=1;
        else
            count+=2;
    }
    printf("%d",count);
    return 0;
}
