#include<stdio.h>
#include<string.h>
int main()
{
    //int n;
    //scanf("%d",&n);
    char s[10000];
    int i,j,k;
    gets(s);
    int flag=0;
    for(i='a',j='A';i<='z';i++,j++)
    {
        flag=0;
        for(k=0;s[k]!='\0';k++)
        {
            if(s[k]==i || s[k]==j)
            {
                flag=1;
                break;
            }
        }
        if(flag==0)
        break;
    }
    if(flag==1)
        {
            printf("YES");
        }
        else
        {
           printf("NO");
        }
     return 0;
}

