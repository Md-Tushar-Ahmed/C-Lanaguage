#include<stdio.h>
#include<string.h>
int main()
{
    int count=0;
    char s[100];
    gets(s);
    int l = strlen(s);
    for(int i=0;i<l;i++)
    {
        for(int j=i+1;j<l;j++)
        {
            for(int k=j+1;k<l;k++)
            {
                if(s[i]=='Q' && s[j]=='A' && s[k]=='Q')
                count++;
            }
        }
    }
    printf("%d",count);
    return 0;
}