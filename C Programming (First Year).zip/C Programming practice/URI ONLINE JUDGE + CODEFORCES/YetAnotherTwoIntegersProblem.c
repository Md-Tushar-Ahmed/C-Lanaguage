#include<stdio.h>
#include<math.h>
int main()
{
    int t,a,b,d;
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        scanf("%d %d",&a,&b);
        d = abs(a-b);
        
        
        printf("%d\n",d/10+(d%10!=0));
    }
    
    return 0;
}