#include<stdio.h>
int main()
{
    int t,x,y,n,k,p;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d%d",&x,&y,&n);
        p=(n-y)/x;
        k=p*x+y;
        printf("%d\n",k);

    }
    return 0;
}