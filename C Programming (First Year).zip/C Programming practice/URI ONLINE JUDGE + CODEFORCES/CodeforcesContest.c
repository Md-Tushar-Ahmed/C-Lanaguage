#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    long long int i,s,j,p,x;
    for(i=0;i<n;i++)
    {
        p=0;
        scanf("%lld",&s);
        if(s%2050==0)
        {
            x=s/2050;
            for(j=0;j>=0;j++)
            {
                p=p+x%10;
                x=x/10;
                if(x<10)
                {
                    p=p+x;
                    break;
                }
            }
            printf("%lld\n",p);
        }
        else printf("-1\n");
    }
}