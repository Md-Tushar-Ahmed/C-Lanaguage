#include<stdio.h>
#include<string.h>
int main()
{
    int i,count=0;
    char s1[101],s2[101];
    gets(s1);
    gets(s2);
    for(i=0; i<strlen(s1); i++)
    {
        if(toupper(s1[i]) > toupper(s2[i]))
        {
            count =1;
            break;
        }


        else if(toupper(s1[i]) < toupper(s2[i]))
        {
            count = -1;
            break;
        }

        else
        {
            count=0;
        }

    }
    printf("%d\n",count);
    return 0;
}
