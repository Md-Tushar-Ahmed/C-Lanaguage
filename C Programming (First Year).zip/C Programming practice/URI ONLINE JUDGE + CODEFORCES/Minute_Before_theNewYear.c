#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    int h,m,new,almin=(24*60);
    while(t--)
    {
        scanf("%d %d",&h,&m);
        new = almin-((h*60)+m);
        printf("%d\n",new);
    }
    return 0;

}