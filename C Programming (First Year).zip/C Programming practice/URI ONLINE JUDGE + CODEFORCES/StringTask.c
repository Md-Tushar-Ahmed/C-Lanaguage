#include<stdio.h>
#include<string.h>
int main()
{

    char str[101];
    int i,l;
    scanf("%s",str);
    l = strlen(str);
    for(i=0;i<l;i++){
        if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u' || str[i]=='y'|| str[i]=='A' || str[i]=='E' || str[i]=='I' || str[i]=='O' || str[i]=='U' || str[i]=='Y')
            continue;
        printf(".%c",tolower(str[i]));
    }
    return 0;

}
