#include<stdio.h>
int main()
{
    int a,n,b,c,count=0,s=0;
    scanf("%d",&n);
    while(n--)
    {
        scanf("%d %d %d",&a,&b,&c);

        if(a==1) count++;
         if(b==1) count++;
          if(c==1) count++;
          if(count>=2) s++;
          count=0;
    }
    printf("%d\n",s);
    return 0;

}
