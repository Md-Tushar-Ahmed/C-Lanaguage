#include<stdio.h>
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    for(int i=1; i<=m; i++)
    {
        for(int j=0; j<n; j++)
        {
            if(i%4==0)
            {
                if(j==n-1)
                    printf("#");
                else
                    printf(".");
            }
            else if(i%4==2)
            {
                if(j==0)
                    printf("#");
                else
                    printf(".");
            }
            else
            {
                printf("#");
            }
        }
        printf("\n");

    }
    return 0;
}
