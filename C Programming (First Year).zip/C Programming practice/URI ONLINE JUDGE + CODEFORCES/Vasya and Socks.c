#include<stdio.h>
int main()
{
    int n,m;

    scanf("%d %d",&n,&m);
    for(int i=1;m*i<=n;i++)
    {
        n++;
    }
    printf("%d",n);
    return 0;
}
