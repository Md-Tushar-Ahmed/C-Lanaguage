#include<stdio.h>
#include<string.h>
int main()
{
    char s[101];
    char t[101];
    scanf("%s",s);
    scanf("%s",t);
    int i,j,f=0,l;
    l = strlen(t); // here s or t two cases are correct
    for(i=0,j=l-1;i<l;i++,j--)
    {
        if(s[i]==t[j])
        {
            f=1;
        }
        else
        {
            f=0;
            break;
        }
    }
    if(f==1)
        printf("YES");
    else
        printf("NO");
    return 0;
}
