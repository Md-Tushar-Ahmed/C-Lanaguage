#include<stdio.h>
int main()
{

    int n,t;
    scanf("%d %d",&n,&t);
    int arr[n];
    for(int i=0; i<(n-1); i++)
    {
        scanf("%d",&arr[i]);
    }
    for(int i=0; i<(n-1);)
    {
        i+=arr[i];
        if(i==t-1)
        {
            printf("YES");
            return 0;

        }

    }

    printf("NO");

    return 0;
}
