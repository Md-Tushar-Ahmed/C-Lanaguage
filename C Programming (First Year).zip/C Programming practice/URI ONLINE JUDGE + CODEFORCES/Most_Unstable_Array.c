#include<stdio.h>
int main()
{
    int t;
    int n,m;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d",&n,&m);
        if(n==1)
        {
            printf("0\n");
        }
        else if(n==2)
        {
            printf("2\n");
        }
        else
        {
            printf("%d\n",n*2);
        }
    }
    return 0;
}