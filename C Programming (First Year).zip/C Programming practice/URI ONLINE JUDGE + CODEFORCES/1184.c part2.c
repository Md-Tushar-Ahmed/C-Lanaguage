#include<stdio.h>

int main()
{
    double N[12][12],sum=0;
    char X[2];
    scanf("%c",&X);
    int n=1,i,j;
    for(i=0;i<12;i++)
    {
        for(j=0;j<12;j++)
        {
            scanf("%lf\n",N[i][j]);
        }
    }
    for(i=1;i<12;i++)
    {
        for(j=0;j<n;j++)// Can not understand this logic(j<n)
        {
            sum=sum+N[i][j];
            n++;
        }
    }
    if(X[0]=='S') printf("%.1lf\n",sum);
    else if(X[0]=='M') printf("%.1lf\n",sum/66.0);
    return 0;
}
