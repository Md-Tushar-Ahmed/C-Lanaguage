#include<stdio.h>
#include<string.h>
int main()
{
    char s[1000];
    int i;
    scanf("%s",s);
    int l = strlen(s);
    int count=0;
    for(int i=0; i<l; i++)
    {
        if(s[i]=='4' || s[i]=='7')
        {
            count++;
        }

    }
    if(count==4 || count==7)
    {
        printf("YES");

    }
    else
    {
        printf("NO");
    }

    return 0;
}
