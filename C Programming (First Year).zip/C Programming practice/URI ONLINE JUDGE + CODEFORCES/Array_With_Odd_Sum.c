#include<stdio.h>
int main()
{
    int sum,even,odd;
    int t,n,i;
    scanf("%d",&t);
    while(t--)
    {
        int sum=0,even=0,odd=0;
        scanf("%d",&n);
        int arr[n];
        for(int i=0;i<n;i++)
        {
            scanf("%d",&arr[i]);
            
            if(arr[i]%2!=0 || arr[i]==1)
            {
                odd++;
            }
            else
            {
                even++;
            }
            sum+=arr[i];
            
            
        }
            if(sum%2 != 0 || sum==1)
            {
                printf("YES\n");
            }
            else if(odd!=0 && even != 0)
            {
                printf("YES\n");
            }
            else
            {
                printf("NO\n");
            } 
        
    }
    return 0;
    
}