#include<stdio.h>
int main()
{

    int m,n,ans;
    scanf("%d %d",&m,&n);
    ans = (m*n)/2;
    printf("%d\n",ans);
    return 0;
}
