#include<stdio.h>
int main()
{
    int k,r,i;
    scanf("%d %d",&k,&r);
    int sum=0;
    for(i=1;;i++)
    {
        sum+=k;
        if((sum%10==0) || (sum%10==r))
        {
            
            printf("%d",i);
            break;
        }
        else
        continue;
    }
    return 0;

}