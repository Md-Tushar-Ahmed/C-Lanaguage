#include<stdio.h>
#include<conio.h>
#include<string.h>
int main()
{
    char str[99];

    scanf("%s",str);
    int m=80;
    int l=strlen(str);
    if(l<=m)
    {
         printf("YES\n");

    }
    else{
             printf("NO\n");

    }

    return 0;
}
