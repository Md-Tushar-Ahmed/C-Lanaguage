#include<stdio.h>
int main()
{
   int i,j=0;
    float n;
    while(1)
    {
        scanf("%f",&n);

    }
}
