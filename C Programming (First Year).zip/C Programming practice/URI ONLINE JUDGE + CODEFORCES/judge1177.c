#include<stdio.h>//Array Fill II
int main()
{
    int i,n,j=0,N[1000];
    scanf("%d",&n);
    for(i=0;i<1000;i++)
    {
        printf("N[%d] = %d\n",i,j);
        j++;
        if(n==j) j=0;
    }
    return 0;


}
