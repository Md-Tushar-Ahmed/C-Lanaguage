#include<stdio.h>
#include<string.h>
int main()
{
    int n,count=0,i;
    scanf("%d",&n);
    char str[n];
    scanf("%s",str);
    for(i=0;i<n;i++)
    {
        if(str[i] == str[i+1])
        {
            count++;
        }
    }
    printf("%d",count);
    return 0;
}
