#include<stdio.h>
#include<math.h>
int main()
{
    int t;
    scanf("%d",&t);
    for(int i=0; i<t; i++)
    {
        int n;
        scanf("%d",&n);
        int arr[n];
        for(int i=0; i<n; i++)
        {
            scanf("%d",&arr[i]);
            int x = sqrt(arr[i]);
            if(x*x==arr[i])
            {
                printf("NO\n");
                //continue;
            }
            else
            {
                printf("YES\n");
            }
        }
    }
    return 0;
}
