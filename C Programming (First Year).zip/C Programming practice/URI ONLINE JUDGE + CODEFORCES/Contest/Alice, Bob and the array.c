#include<stdio.h>
int main()
{
    int T,N;
    scanf("%d",&T);
    scanf("%d",&N);
    int arr[N];
    int sum=0;
    for(int i=0;i<T;i++)
    {
        for(int j=1;j<n;j++)
        {
            scanf("%d ",&arr[j]);
            if(arr[j]>arr[j+1])
            {
                swap(arr[j],arr[j+1]);
            }
        }
        sum+=arr[j];
    }
    printf("%d",sum);
    return 0;
}
