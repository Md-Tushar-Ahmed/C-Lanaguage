#include<stdio.h>
int main()
{
    int t,i,j,x;
    scanf("%d",&t);
    int arr[50]={0};
    for(i=0;i<t;i++)
    {
        scanf("%d",&x);
        if(x==0){
            printf("0 0\n");
        }
        else if(x==20){
            printf("10 10\n");
        }
        else if(x<11){
            printf("%d %d\n",arr[x],abs(x-arr[x]));
            arr[x]++;
        }
        else {
            int y = 10-arr[x];
            printf("%d %d\n",y,arr[x-y]);
            arr[x]++;
        }
    }
    return 0;
}
