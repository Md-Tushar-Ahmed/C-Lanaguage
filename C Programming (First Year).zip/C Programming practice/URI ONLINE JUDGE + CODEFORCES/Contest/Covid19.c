#include<stdio.h>
int main()
{
    int N;
    scanf("%d",&N);
    int count=1;
    if(N<6)
    {
        printf("%d",count);
    }
    else
    {
        int r=N/6;
        r++;
        printf("%d",r);
    }
    return 0;
}
