#include<stdio.h>
int main()
{
    int a,b;
    scanf("%d %d",&a,&b);
    if(a>b)
        printf("%d ",b);
    else
        printf("%d ",a);
    int x=abs(a-b);
    printf("%d",x/2);
    return 0;
}
