#include<stdio.h>
int main()
{
    int t,l,r;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d",&l,&r);
        if(r>=2*l)
        {
            printf("%d %d\n",l,2*l);
        }
        else
        {
            printf("-1 -1\n");
        }
    }
}