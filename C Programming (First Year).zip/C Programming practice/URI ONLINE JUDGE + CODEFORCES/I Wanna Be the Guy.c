#include<stdio.h>
int main()
{
    int n,i,j,p,q,f=0;
    scanf("%d",&n);
    scanf("%d",&p);
    int arr1[p];
    for(i=0;i<p;i++)
    {
        scanf("%d",&arr1[i]);
    }
    scanf("%d",&q);
    int arr2[q];
    for(i=0;i<q;i++)
    {
        scanf("%d",&arr2[i]);
    }
    for(i=1;i<=n;i++)
    {
        for(j=0;j<p;j++)
        {
            if(i==arr1[j])
            {
                f=1;
                break;
            }
            else
            f=0;
        }
        if(f==0)
        {
            for(j=0;j<q;j++)
            {
                if(i==arr2[j])
                {
                    f=1;
                    break;
                }
                else
                f=0;
            }
        }
        if(f==0)
        break;
    }
    if(f==1)
    printf("I become the guy.");
    else
    printf("Oh, my keyboard!");
    return 0;


}