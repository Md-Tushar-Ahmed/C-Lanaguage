#include<stdio.h>
#include<string.h>
int main()
{
    int t,i,j;

    scanf("%d",&t);
    while(t--)
    {
        char a[100],b[100];
        scanf("%s",&b);
        int l = strlen(b);

            if(l==2)
            {
                printf("%s\n",b);
            }
            else
            {

                a[0] =b[0];
                a[1] =b[1];
                for(i=3,j=2;i<l;i+=2,j++)
                {
                    a[j] = b[i];
                }
                a[j] = '\0';
                printf("%s\n",a);

            }

    }
    return 0;
}