#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int arr[n];
    int i,r;
    for(int i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);

    }
    for(int j=1;j<=n;j++)
    {
        for(int k=0;k<n;k++)
        {
            if(arr[k]==j)
            {
                r=k+1;
                printf("%d ",r);
            }

        }
    }

    return 0;
}
