 #include<stdio.h>
 int main()
 {
     int i,j;
     for(i=1;i<10;i+=2)
     {
         for(j=7;j>=5;j--)
            printf("I=%d J=%d\n",i,j);
     }
     return 0;
 }
