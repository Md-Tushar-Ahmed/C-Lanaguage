#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    int count=1;
    for(int i=1;i<n/2;i++)
    {
        int t = n - i;
        if(t % i == 0)
        {
            count++;
        }
    }
    printf("%d",count);
}