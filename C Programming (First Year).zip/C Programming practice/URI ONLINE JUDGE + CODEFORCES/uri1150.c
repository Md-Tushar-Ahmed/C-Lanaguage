#include<stdio.h>
int main()
{
    int x,y,count=1,i,sum=0;
    scanf("%d %d",&x,&y);
    while(y<=x) scanf("%d",&y);
    for(i=x;i<=y;i++){
        sum+=i;
        if(sum>y) break;
        count++;

    }
    printf("%d\n",count);
    return 0;
}