#include <stdio.h>
int main()
{
    int n;
    int ammount;
    char type, p = '%';
    int C,R,S,total;
    C= R= S= total = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d %c", &ammount, &type);
        if ('C' == type)
            C += ammount;
        else if ('R' == type)
            R += ammount;
        else if ('S' == type)
            S += ammount;
        total += ammount;
    }
    printf("Total: %d cobaias\n", total);
    printf("Total de coelhos: %d\n", C);
    printf("Total de ratos: %d\n", R);
    printf("Total de sapos: %d\n", S);
    printf("Percentual de coelhos: %.2f %c\n", C * 100.0 / total, p);
    printf("Percentual de ratos: %.2f %c\n", R * 100.0 / total, p);
    printf("Percentual de sapos: %.2f %c\n", S * 100.0 / total, p);
    return 0;
}