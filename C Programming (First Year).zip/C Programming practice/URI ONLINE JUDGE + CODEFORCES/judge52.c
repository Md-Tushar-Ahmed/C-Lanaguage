#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    if(n==1) printf("January\n");
    if(n==2) printf("February\n");
    if(n==3) printf("March\n");
    if(n==4) printf("April\n");
    if(n==5) printf("May\n");
    if(n==6) printf("June\n");
    if(n==7) printf("July\n");
    if(n==8) printf("August\n");
    if(n==9) printf("September\n");
    if(n==10) printf("October\n");
    if(n==11) printf("November\n");
    if(n==12) printf("December\n");
    return 0;

}
