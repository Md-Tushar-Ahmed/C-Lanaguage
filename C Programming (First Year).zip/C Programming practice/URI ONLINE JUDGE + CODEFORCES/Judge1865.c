#include<stdio.h>
int main()
{
    int C,i,b;
    scanf("%d",&C);
    char str[1000];
    for(i=0;i<C;i++){
        scanf("%s %d",str,&b);
        if(!strcmp(str,"Thor"))//! mean ?
            printf("Y\n");
        else printf("N\n");
    }
    return 0;
}
