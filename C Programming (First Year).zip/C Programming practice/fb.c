#include<stdio.h>
int main()
{
   char str[50];
   int i;
   puts("Enter a string:");
   gets(str);
   for(i=0;str[i]!='\0';i++)
   {
       if(i==0)
        putchar(str[i]);
       if(str[i]==' ')
       {
           printf("\n");
        putchar(str[i+1]);
       }

   }
    return 0;
}
