#include<stdio.h>
int main()
{
    int Input;
    printf("Enter the Alphabet:");
    scanf("%c",&Input);
    if(Input=='a'||Input=='A'||Input=='e'||Input=='E'||Input=='i'||Input=='I'||Input=='o'||Input=='O'||Input=='u'||Input=='U')
    {
        printf("The Letter is vowel",Input);
    }
    else
    {
        printf("The Letter is cosonent",Input);
    }
    return 0;

}
