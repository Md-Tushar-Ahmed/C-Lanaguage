#include<stdio.h>
#include<string.h>
int main()
{
    char str1[15]="Tushar";
    char str2[15]="Ahmed";
    char temp[15];
    strcpy(temp,str1);
    strcpy(str1,str2);
    srecpy(str2,temp);

    printf("str1=%s\n",str1);
    printf("str2=%s\n",str2);

}
