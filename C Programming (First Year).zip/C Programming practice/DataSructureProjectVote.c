#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<windows.h>
#include<conio.h>
typedef struct voter_information
{
    char id[10];
    char name[20];
    char birth_date[15];
    char father_name[20];
    char mother_name[20];
    struct voter_information next;

} node;
node *head;
int count1=0,count2=0,count3=0,count4=0,count5=0;
int main()
{
    system("cls");

    printf("\n\n\n");
    printf("\t         ..........WELCOME TO ONLINE VOTING SYSTEM.........\n\n\n");
    printf("\t       ----................................----------\n\n\n\n\n");
    printf("    \t\t......Please Enter one(1) for logging vote main loges......\n\n\n");
    int B;
    scanf("%d",&B);
    if(B==1)
    {
        main_loges();
    }

    return 0;
}
void main_loges()
{
    system("cls");

    printf("\n\n\n");
    printf("     \t\t\t\t 1.FOR VOTE ENTRY------|||\n");
    Sleep(300);
    printf("     \t\t\t\t 2.FOR ADMIN PANEL-----|||\n");
    Sleep(300);
    printf("      \t\t\t\t 3.FOR WINNER  -------|||\n");
    Sleep(300);
    printf("       \t\t\t\t 4.FOR EXIT   --------|||\n\n\n");
    printf("   \t----After voter entry you can give your vote otherwise you can't------\n\n\n");
    Sleep(300);
    printf("     \t----------SO PLEASE ENTER (1) ----------\n\n\n");
    int T;
    scanf("%d",&T);
    if(T==1)
    {
        voter_insert();

    }
    if(T==2)
    {
        admin();
    }
    if(T==3)
    {
        winner();
    }
    if(T==4)
    {
        exi();
    }

}
int count=0,count=0,R=3;
void voter_insert()
{
    node *temp;

    char name[25],birth_date[24],f_name[25],m_name[25],id[10];
    system("cls");
    printf("\n\n\n\n");
    printf("\tIF NATIONAL ID,YOUR NAME,BIRTH DATE,YOUR FATHER NAME AND MOTHER NAME MATCH YOU CAN GIVE VOTE OTHERWISE NOT\n\n");
    Sleep(300);
    printf("\t\t\tIF YOU DO WRONG (%d) TIME,THE PROGRAMME WILL BE STOPPED AUTOMITICALLY\n\n\n",R);
    Sleep(300);
    printf("\t\tPLEASE.........\n");
    Sleep(300);
    printf("\t\t\t\tENTER YOUR NATIONAL ID NUMBER      ");
    gets(id);
    gets(id);
    printf("\t\t\t\tENTER YOUR NAME                    ");
    gets(name);
    printf("\t\t\t\tENTER YOUR BIRTH DATE              ");
    gets(birth_date);
    printf("\t\t\t\tENTER YOUR FATHER NAME             ");
    gets(f_name);
    printf("\t\t\t\tENTER YOUR MOTHER NAME             ");
    gets(m_name);
    temp=(node *)malloc(sizeof(node));
    strcpy(temp->id,id);
    strcpy(temp->name,name);
    strcpy(temp->birth_date,birth_date);
    strcpy(temp->father_name,f_name);
    strcpy(temp->mother_name,m_name);
    temp->next=NULL;
    head=temp;
    while(temp != NULL)
    {

        if((strcmp(temp->id,"10000001")==0 && strcmp(temp->name,"Seikh Hasina")==0 && strcmp(temp->birth_date,"09-05-1950")==0 && strcmp(temp->father_name,"Sheikh Mojibor Rahman")==0 && strcmp(temp->mother_name,"Sheikh Fazilatunnisa")==0) ||
                (strcmp(temp->id,"10000002")==0 && strcmp(temp->name,"Sajib Wazed Joy")==0 && strcmp(temp->birth_date,"27-07-1971")==0 && strcmp(temp->father_name,"Rasel Mia")==0 && strcmp(temp->mother_name,"Amena Begum")==0) ||
                (strcmp(temp->id,"10000003")==0 && strcmp(temp->name,"Khaleda Zia")==0 && strcmp(temp->birth_date,"19-04-1945")==0 && strcmp(temp->father_name,"Emon Ahmed")==0 && strcmp(temp->mother_name,"Bindu Akter")==0) ||
                (strcmp(temp->id,"10000004")==0 && strcmp(temp->name,"Tareq Rahman")==0 && strcmp(temp->birth_date,"12-02-1973")==0 && strcmp(temp->father_name,"Abdullah Mia")==0 && strcmp(temp->mother_name,"Shila Akter")==0) ||
                (strcmp(temp->id,"10000005")==0 && strcmp(temp->name,"Hossen Md Ersad")==0 && strcmp(temp->birth_date,"11-02-1935")==0 && strcmp(temp->father_name,"Milon Mia")==0 && strcmp(temp->mother_name,"Shagorika Akter")==0) ||
                (strcmp(temp->id,"10000006")==0 && strcmp(temp->name,"Rakibul Islam")==0 && strcmp(temp->birth_date,"02-01-1955")==0 && strcmp(temp->father_name,"Masum Ahmed")==0 && strcmp(temp->mother_name,"Shuma Begum")==0) ||
                (strcmp(temp->id,"10000007")==0 && strcmp(temp->name,"Tushar Ahmed")==0 && strcmp(temp->birth_date,"29-04-1958")==0 && strcmp(temp->father_name,"Tofazzal Hossain")==0 && strcmp(temp->mother_name,"Moriom Akter")==0) ||
                (strcmp(temp->id,"10000008")==0 && strcmp(temp->name,"Redoy Khan")==0 && strcmp(temp->birth_date,"01-01-1980")==0 && strcmp(temp->father_name,"Sumon Ahmed")==0 && strcmp(temp->mother_name,"Mukhty Begun")==0) ||
                (strcmp(temp->id,"10000009")==0 && strcmp(temp->name,"Sabiha Akter")==0 && strcmp(temp->birth_date,"09-05-1967")==0 && strcmp(temp->father_name,"Kalam Ali")==0 && strcmp(temp->mother_name,"Zoba Begum")==0))

            // } confused part start second bracket guess
            count++;
        if(count>1)
        {
            not_again();
            break;
        }
        voting();

    }
    else
    {
        R--;
        count++;
        if(count==3)
        {
            stop();
            break;
        }
        printf("\n\n\n\n");
        printf("\t\tYou voter Id or Name or Date of birth or Father's name is wrong\n\n");
        Sleep(300);
        system(pause);
        main_loges();
    }
    temp=temp->next;
}
}//confused part finish
void voting()
{
    system("cls");
    printf("\n\n\n\n");
    printf("\t\t  =======LIST OF THE CANDIDATES=========\n\n\n");
    sleep(300);
    printf("\t\t\t NAME---------------------SYMBOL\n\n");
    Sleep(300);
    printf("\t\t\t 1.Seikh Hasina            1.Boat\n");
    sleep(300);
    printf("\t\t\t 2.Sajib Wazed Joy           2.Flag\n");
    sleep(300);
    printf("\t\t\t 3.Khaleda Zia           3.Mango\n");
    sleep(300);
    printf("\t\t\t 4.Tareq Rahman           4.Pine Apple\n");
    sleep(300);
    printf("\t\t\t 5.Hossen Md Ersad           5.Book\n");
    sleep(300);
    printf("\t\t\t 6.Rakibul Islam           6.Laptop\n");
    sleep(300);
    printf("\t\t\t 7.Tushar Ahmed           7.Jack Fruit\n");
    sleep(300);
    printf("\t\t\t 8.Redoy Khan           8.Banana\n");
    sleep(300);
    printf("\t\t\t 9.Sabiha Akter           9.Star\n");

    int B,j;
    printf("\t\t\t Print ------\n");
    printf("\t\t\t\t Enter Your Choice  ");
    for(j=1; j<=1; j++)
    {
        printf("%d",&B);
        if(B==1)
        {
            count1++;
        }
        if(B==2)
        {
            count2++;
        }
        if(B==3)
        {
            count3++;
        }
        if(B==4)
        {
            count4++;
        }
        if(B==5)
        {
            count5++;
        }
        if(B !=1 && B!=2 && B!=3 && B!=4 && B!=5)
        {
            printf("\t\t\t\t Your Vote is Invalid\n");
            main_loges();
        }
    }
    int R;
    system("cls");
    printf("\n\n\n\n");
    printf("\t\t\t If You Want to see present winner enter one (1) or \n\n\n \t\t\t\t\t Zero for main loges\n\n\n");
    scanf("%d",&R);
    if(R==1)
    {
        winner();
    }
    if(R!=1)
    {
        main_loges();
    }

}
void admin()
{
    int B;
    printf("\n\n\n\n");
    printf("\t\t\tEnter password to admin panel\n\n");
    scanf("%d",&B);
    if(B==10715)
    {
        show();
    }
    else
    {
        exi();
    }

}
void winner()
{
    system("cls");
    printf("\n\n\n\n");
    if(count2>count1 && count3>count1 && count4>count1 && count5>count1)
        printf("\t\t\tThe present winner person is Begum Khaleda Zia and she got %d votes \n\n\n\n\n",count1);
    if(count1>count5 && count2>count5 && count3>count5 && count4>count5)
        printf("\t\t\tThe present winner person is Emon and He got %d votes \n\n\n\n\n",count5);//Whose name ?
    //condition should be added
    int T;
    printf("\t\t\t\tEnter one(1) For Main Loges \n\n\t\t\t\t\tZero For Exit\n");
    scanf("%d",&T);
    if(T==1)
    {
        main_loges();
    }
    if(T != 1)
    {
        exi();
    }


}
void stop()
{
    stytem("cls");
    printf("\n\n\n");
    printf("\t----Sorry, You can not give your vote for your wrong entry times---\n\n\n");
    sleep(300);
    printf("\t\t--Please try again after a few times---\n\n\n\n");
    Sleep(300);
    printf("\t\t  Thank You......\n\n\n");
    Sleep(300);

}
void not_again()
{

    system("cls");
    printf("\n\n\n");
    printf("\t\t\t...YOU HAVE GIVE YOUR VOTE SUCCESSFULLY....\n\n\n");
    Sleep(300);
    printf("  \t\t .. SO YOU CAN'T GIVE YOUR VOTE MORE THAN ONE TIMES..\n\n\n");
    Sleep(300);
    printf("\t\t IF YOU WANT TO SEE PRESENT WINNER ENTER ONE (1) OR TWO (2) FOR MAIN Loges\n\n");
    Sleep(300);
    printf("\t\t\t ZERO FOR EXIT\n\n");
    scanf("%d",&R);
    if(R==1)
    {
        winner();
    }
    if(R==2)
    {

        main_loges();
    }
    if((R!=1) || (R!=2))
    {
        exi();
    }

}
void exi()
{
    system("cls");
    printf("\n\n\n");
    printf("\t\t-----YOU HAVE GIVE YOUR VOTE SUCCESSFULLY --------\n\n\n");
    Sleep(300);
    printf("\t\t\t\t .....THANK YOU......\n\n\n");
    Sleep(300);
}



