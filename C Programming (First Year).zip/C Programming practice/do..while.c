#include<stdio.h>
int main()
{
    int i;
    i=1;
    do
    {
        printf("Let me go\n");
        i=i+1;
    }
    while(i<=5);
    return 0;
}
