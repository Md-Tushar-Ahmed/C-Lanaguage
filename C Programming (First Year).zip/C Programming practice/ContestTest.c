#include<stdio.h>
#include <stdlib.h>
#include <string.h>
#include<stdbool.h>
int main()
{

    int t,n;
    scanf("%d",&t);
    while(t--)
    {
        bool memo[1024];
        scanf("%d",&n);
        int police[n],student[n],studentCount=0;
        memset(memo,false,sizeof(memo));
        for(int i=0; i<n; i++) scanf("%d", &student[i]);
        for(int i=0; i<n; i++) scanf("%d", &police[i]);
        int max_police = police[0];
        for(int i=1; i<n; i++) {
            if(police[i] > max_police) max_police = police[i];
        }
        // printf("%d\n",max_police);
        for(int i=0; i<n; i++) {
            if(student[i] <= max_police && memo[student[i]] == false) {
                studentCount++;
                memo[student[i]] = true;
            }
        }

        printf("%d\n",studentCount);
    }
    return 0;
}
