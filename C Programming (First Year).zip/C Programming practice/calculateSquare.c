#include<stdio.h>
int main()
{
    int r,i,sqr;
    printf("Enter the Range :");
    scanf("%d",&r);
    for(i=1;i<=r;i++)
    {
        sqr=i*i;
        printf("Square of %d is:%d\n",i,sqr);
    }
    return 0;
}
