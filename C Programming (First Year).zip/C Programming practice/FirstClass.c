#include<stdio.h>
int main()
{

    int a,b,c,max;
    printf("Enter Three Numbers:\n");
    scanf("%d %d %d",&a,&b,&c);
    max=a;
    if(max<b)
    {
        max=b;
    }
    if(max<c)
    {
        max=c;
    }
    printf("The Maximum Value is : %d\n",max);
    return 0;
}
/*Algorithm :
    1. Start
    2. Input three numbers(a,b,c)
    3. consider max=a. if max is less then b then maximum number is b
    4. On the other hand , if max value is less then c then maximum value is c
    5. Output */
