#include<stdio.h>

void display(int x[])
{
    int i;
    for(i=0;i<6;i++)
    {
        printf("%d ",x[i]);
    }
}
int main()
{
    int num[]={2,4,6,8,10,12};
    display(num);

}
