#include<stdio.h>
#include<math.h>
int main()
{
    int x;
    x=pow(5,2);
    printf("%d", x);
    return 0;
}
