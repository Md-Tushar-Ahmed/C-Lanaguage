#include<stdio.h>
#include<stdlib.h>
int main()
{
    int i,a,j,n,*p[10];

    int temp,r,sum=0;
    printf("Enter the number:");
    scanf("%d",&n);
    *p = (int*)malloc(n*sizeof(int));
    printf("Enter the Elements:\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&p[i]);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(p[i]>p[j])
            {
                a=p[i];
                p[i]=p[j];
                p[j]=a;
            }
        }
    }
        printf("\nSorted Numbers:\n");
        for(i=0;i<n;i++)
        {
            printf("%d ",p[i]);
        }
        /*temp=p[i];
      while(temp != 0){
        r=temp%10;
        sum=sum+r;
        temp=temp/10;
      }
      printf("\nSum of digits:%d\n",sum+=p[i]);*/


    return 0;
}
