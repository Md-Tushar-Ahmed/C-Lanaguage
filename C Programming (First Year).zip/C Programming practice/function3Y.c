#include<stdio.h>

 void CalculatePower(double base,double exp)
{
    double power;
    power=pow(base,exp);
    printf("The result of the Math:%lf",power);
}
int main()
{
    double base,exp;
    printf("Enter the Base:");
    scanf("%lf",&base);
    printf("Enter the exponent:");
    scanf("%lf",&exp);

    CalculatePower(base,exp);
}
