#include<stdio.h>
#include<string.h>
int main()
{
    int n;
    scanf("%d",&n);
    char str[100];
    for(int i=0; i<n; i++)
    {
        scanf("%s",str);
        int l=strlen(str);
        if(l>0 && l<=25)
            printf("Y\n");
        else
            printf("N\n");

    }
    return 0;
}
