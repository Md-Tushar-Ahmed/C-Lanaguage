#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
    time_t t;
    srand((unsigned)time(&t));

    int choosen_number;
    int lucky_number =rand()%10+1;
    while(1)
    {

        printf("Enter Your Guess Number : ");
        scanf("%d",&choosen_number);
        if(lucky_number==choosen_number)
        {
            printf("Congratulation ! You have win the game");
            break;
        }
    }
    return 0;
}
