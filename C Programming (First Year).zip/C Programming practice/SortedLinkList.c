#include <stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node *Link;
};
struct Node *head;
void print()
{
    struct Node *temp;
    temp=head;
    while(temp != NULL)
    {
        printf("%d ",temp->data);
        temp=temp->Link;
    }
    printf("\n");
}
void insert(int value)
{
    struct Node* temp1=(struct Node*)malloc(sizeof(struct Node));
    temp1->data=value;
    if(head==NULL){
        temp1->Link = head;
        head = temp1;
    }
    if(temp1->data<head->data){
        temp1->Link = head;
        head = temp1;
    }
    else{
        struct Node *pred = head;
        struct Node *p = pred->Link;
        while(p != NULL &&temp1->data>p->data){
            pred = p;
            p = p->Link;
        }
        pred->Link = temp1;
        temp1->Link = p;

    }

}
int main()
{
    head=NULL;
    insertAtEnd(4);
    insertAtEnd(10);
    insertAtEnd(13);

    insert(20);
    print();

    return 0;
}

void insertAtEnd(int value)
{
struct Node* temp=(struct Node*)malloc(sizeof(struct Node));
temp->data=value;
temp->Link=NULL;
if(head==NULL){
head=temp;
}
else {
struct Node *t;
t=head;
while(t->Link != NULL){
t=t->Link;
}
t->Link=temp;
}
}
