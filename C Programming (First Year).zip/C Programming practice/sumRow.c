#include<stdio.h>
int main()
{
    int A[10][10],num_row,num_col,sum=0,i,j;
    printf("Enter the number of rows and columns:");
    scanf("%d %d",&num_row,&num_col);

    printf("Enter the elements of Matrix:\n");
    for(i=0;i<=num_row;i++)
    {
        for(j=0;j<=num_col;j++)
        {
            printf("A[%d][%d]=",i,j);
            scanf("%d",&A[i][j]);
        }
    }

  for(i=0;i<=num_row;i++)
    {
        for(j=0;j<=num_col;j++)
        {
            printf("%d ",A[i][j]);;

        }
        printf("\n");
    }
    for(i=0;i<=num_row;i++)
    {
        for(j=0;j<=num_col;j++)
        {
            sum=sum+A[i][j];
        }
        printf("Sum of %d row:%d\n",i+1,sum);
        sum=0;
    }
    return 0;

}
