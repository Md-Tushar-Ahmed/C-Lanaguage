#include<stdio.h>
int main()
{
    int A[10][10],B[10][10],result[10][10],i,j,k,r1,r2,c1,c2,sum;
    printf("Enter rows and col for A matrix:");
    scanf("%d %d",&r1,&c1);
    printf("Enter rows and col for B matrix:");
    scanf("%d %d",&r2,&c2);
    while(c1 != r2)
    {
        printf("ERROR!");
        printf("Enter rows and col for A matrix:");
        scanf("%d %d",&r1,&c1);
         printf("Enter rows and col for B matrix:");
        scanf("%d %d",&r2,&c2);

    }

    printf("Enter A matrix.\n");

    for(i=0;i<r1;i++)
    {
        for(j=0;j<c1;j++)
        {
            printf("A[%d][%d]=",i,j);
            scanf("%d",&A[i][j]);
        }

    }
     printf("Enter B matrix.\n");

    for(i=0;i<r2;i++)
    {
        for(j=0;j<c2;j++)
        {
            printf("B[%d][%d]=",i,j);
            scanf("%d",&B[i][j]);
        }

    }
     for(i=0;i<r1;i++)
    {
        for(j=0;j<c2;j++)
        {
            for(k=0;k<c1;k++)
            {
                sum=0;

                sum=sum+A[i][k]*B[k][j];

            }
            result[i][j]=sum;
            sum=0;

        }
    }
     printf("\nA Matrix =\n ");
    for(i=0;i<r1;i++)
    {

        for(j=0;j<c1;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf(" \n ");
    }

     printf("\nB Matrix=\n ");
     for(i=0;i<r2;i++)
    {


        for(j=0;j<c2;j++)
        {
            printf("%d ",B[i][j]);
        }
        printf(" \n ");
    }

     printf("\nResult=\n ");
    for(i=0;i<r1;i++)
    {


        for(j=0;j<c2;j++)
        {
            printf("%d ",result[i][j]);
        }
        printf(" \n ");
    }
    return 0;

}
