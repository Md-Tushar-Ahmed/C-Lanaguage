#include <stdio.h>
void removeChar(char *s, int c){

	int j, n = strlen(s);
	for (int i=j=0; i<n; i++)
	if (s[i] != c)
		s[j++] = s[i];

	s[j] = '\0';
}

int main()
{
char s[] = "IIUC CSE";
removeChar(s, 'I');
printf("%s\n",s);
return 0;
}
