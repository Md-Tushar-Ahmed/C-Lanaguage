//hackerrank-(alternative character)
#include<stdio.h>
#include<string.h>

int main()
{
    int n,j,i,l,count=0;
    scanf("%d",&n);
    char str[10000];
    for(i=0; i<n; i++)
    {
        count=0;
        scanf("%s",str);
        l = strlen(str);
        for(j=0; j<l-1; j++)
        {
            if(str[j]==str[j+1])
                count++;
        }
        printf("%d\n",count);
    }
    return 0;
}
