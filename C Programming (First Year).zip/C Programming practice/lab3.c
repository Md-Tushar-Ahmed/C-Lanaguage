#include<stdio.h>

int main()

{

    int i;

   float array[6];

   for(i=1;i<50;i++)

   {

       printf("\n%f ",array[6]);

   }

   printf("\nOutput\n");

   for(i=1;i<50;i++)

   {

       printf("\n%d ",array[6]);

   }

   return 0;

}

