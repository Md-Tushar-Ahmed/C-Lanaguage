#include<stdio.h>
int main()
{
    int A,B,x;
    A=15,B=-7;
    scanf("%d %d",&A,&B);
    x=A+B;
    printf("X=%d\n",x);
    return 0;
}
