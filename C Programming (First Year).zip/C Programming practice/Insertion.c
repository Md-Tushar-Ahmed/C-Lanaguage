#include<stdio.h>
//Insertion sort Time complexity :0(n^2)
//Space Complexity 0(1)
int main()
{
    int a[]={1,4,7,2,5};
    int i,value,hole;
    for(i=1;i<5;i++){
        value=a[i];
        hole=i;
        while(hole>0 && a[hole-1]>value) {
        a[hole]=a[hole-1];
        hole--;
    }
    a[hole]=value;
    }
    printf("Sorted Array\n");
    for(i=0;i<5;i++){
        printf("%d ",a[i]);
    }
    return 0;

}
