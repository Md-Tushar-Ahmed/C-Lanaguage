#include<stdio.h>

int maximum(int x[])
{
    int i;
    int max=x[0];
    for(i=1;i<6;i++)
    {
        if(max<x[i]);
        max=x[i];
    }
    return max;
}
int main()
{
    int num[]={2,4,6,8,10,12};
   int maximumValue= maximum(num);
   printf("Maximum= %d\n",maximumValue);


}
