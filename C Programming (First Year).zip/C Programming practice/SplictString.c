#include<stdio.h>
#include<string.h>
int main()
{
    char str[51];
    int i;
    printf("Enter a string : ");
    gets(str);
     for(i=0;str[i]!='\0';i++)
   {
       //if(i==0)
        //putchar(str[i]);
       if(str[i]==' ')
       {
           printf("\n");

       }

   }
   return 0;
}
