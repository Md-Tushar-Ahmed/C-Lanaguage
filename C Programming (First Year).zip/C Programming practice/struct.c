#include<stdio.h>
struct student
{
    int id;
    float cgpa;
    char name[10];
};
int main()
{
    struct student s;
    printf("Enter your id: \n");
    scanf("%d",&s.id);
    printf("Enter your cgpa: \n");
    scanf("%f",&s.cgpa);
    printf("Enter your name: \n");
    scanf("%d",&s.name);

    printf("Name: %s; Id: %d; cgpa:%f\n",s.name,s.id,s.cgpa);
    return 0;
}

