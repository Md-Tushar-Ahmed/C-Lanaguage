#include<stdio.h>
#include<process.h>
#include<windows.h>
#include<conio.h>

void gotoxy(int x,int y)
{

    COORD coord;
    coord.X = x;
    coord.Y = y;

    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),coord);

}
int main()
{
    int r,q;
    gotoxy(32,36);
    printf("Loading......\n");
    gotoxy(32,38);
    for(r=1; r<=20; r++)
    {
        for(q=0; q<=100000000; q++);

        printf("%c",177);

    }
    return 0;

}
