#include<stdio.h>
int main()
{
    char my_char;
    my_char='6';
    my_char='M';
    printf("%c\n",my_char);
    return 0;
}
/////char -last value printed always
