#include<stdio.h>
#include<string.h>
int main()
{
    char A[100],B[100];
    printf("Enter the first string:");
    gets(A);
    printf("Enter the second string:");
    gets(B);
    if(strcmp(A,B)==0)
        printf("Enter string are equal\n");
    else
        printf("Enter string are not equal\n");
        return 0;

}
