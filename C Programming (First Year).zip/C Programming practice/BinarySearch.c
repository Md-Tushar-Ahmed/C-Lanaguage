#include<stdio.h>
int main()
{
    int a[]={1,2,4,5,67,89,100};
    int item=5;
    int left=0;
    int right=6;
    int middle;
    //Runtime complexity:0(logN)
    //Space Complexity : 0(1)
    while(left<=right) {
       middle=(left+right)/2;
       if(a[middle]==item){
        printf("Item found at:%d index\n",middle);
        return 0;
       }
       else if(a[middle]<item){
        left=middle+1;
       }
       else{
        right=middle-1;
       }
    }
    printf("Item not Found\n");
    return 0;

}
