#include <stdio.h>
char conver_to_lower(char ch) {
return ch + 32;
}
char conver_to_upper(char ch) {
return ch - 32;
}
int main ()
{
int c = 0;
char ch, s[1000];
printf("Input the string:\n");
gets(s);
while (s[c] != '\0') {
ch = s[c];
if (ch >= 'A' && ch <= 'Z')
s[c] = conver_to_lower(s[c]);
else if (ch >= 'a' && ch <= 'z')
s[c] = conver_to_upper(s[c]);
c++;
}
printf("Output of the String:\n%s", s);
return 0;
}
