#include<stdio.h>
int main()
{
    int i,marks[2];
    for(i=0;i<=2;i++)
    {
        scanf("%d",&marks[i]);
    }
    for(i=0;i<=2;i++)
    {
        if(marks[i]>0)
        {


        printf("marks[%d]=%d\n",i,marks[i]);
        break;
        }

    }
    return 0;
}
