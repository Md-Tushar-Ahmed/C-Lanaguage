#include<stdio.h>
int main()
{
    int i,j,min;
    int arr[]= {12,9,7,2,5,1};
    for(i=0; i<6; i++)
    {
        min=i;
        for(j=i+1; j<6; j++)
        {
            if(arr[j]<arr[min])
            {
                min=j;
            }

        }
        int temp=arr[i];
        arr[i]=arr[min];
        arr[min]=temp;

    }
    printf("\nSelection Sort :\n");
    for(i=0; i<6; i++)
    {

      printf("%d ",arr[i]);
    }
    printf("\n\n");
    return 0;
}
