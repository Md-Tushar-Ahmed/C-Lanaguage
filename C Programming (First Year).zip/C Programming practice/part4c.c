#include <stdio.h>
int main()
{
    int a, b, c, i, terms;
    scanf("%d", &terms);
    a = 0;
    b = 1;
    c = 0;
    for(i=1; i<=terms; i++)
    {
        printf("%d-th term of negative Fibonacci series: %d\n",i,c);
        a = b;
        b = c;
        c = a - b;
    }
    return 0;
}
