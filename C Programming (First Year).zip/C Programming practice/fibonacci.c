#include<stdio.h>
int main()
{
   int first=0,second=1,fibonacci,n,count=0;
   printf("Enter Fibonacci Range : ");
   scanf("%d",&n);
   while(count<n){
    if(count<=1){
        fibonacci=count;
    }
    else {
        fibonacci=first+second;
        first=second;
        second=fibonacci;
    }
    printf("%d ",fibonacci);
    count++;

   }
    return 0;
}
