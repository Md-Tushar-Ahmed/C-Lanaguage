#include<stdio.h>
void display(char ch)
{

    printf("\n%c ",ch);
}
int main()
{
    char arr[]={'a','b','c','d','e'};
    for(int x=0;x<5;x++)
    {
        display( arr[x]);

    }


}
