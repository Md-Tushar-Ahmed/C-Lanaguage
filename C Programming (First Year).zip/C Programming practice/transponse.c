#include<stdio.h>>
int main()
{
    int i,j,A[2][2],B[2][2];
    printf("Enter elements for A matrix:\n");
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            printf("A[%d][%d]=",i,j);
            scanf("%d",&A[i][j]);
        }
        printf("\n");
    }

      printf("\nA matrix:\n");
    for(i=0;i<2;i++)
       {
        printf("\t");
        for(j=0;j<2;j++)
        {
            printf("%d ",A[i][j]);
        }
        printf("\n");
    }
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            A[i][j]=B[j][i];
        }
    }
    printf("\nTransponse Matrix :\n");
    for(i=0;i<2;i++)
    {
        printf("\t");
        for(j=0;j<2;j++)
        {
            printf("%d ",B[i][j]);
        }
        printf("\n");
    }
    return 0;
}




