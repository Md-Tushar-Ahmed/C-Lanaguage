#include<stdio.h>
int main()
{
    FILE *file;
    char name[20];
    int length;
    length = strlen(name);
    int i;
    file = fopen("text.txt","w");
    if(file == NULL){
        printf("File doesn't exist\n");
    }
    else{
        printf("File is opened\n");
        printf("Enter your Full Name:");
        gets(name);
        fputs(name,file);//2 perameter fputs(string,pointer)
        printf("File is Written Successfully\n");
        fclose(file);
        }


    return 0;
}

