#include<stdio.h>

    int result(int a,int b)
{
     return a+b;
}
int main()

{
    int num1,num2;
    printf("Enter two number:");
    scanf("%d %d",&num1,&num2);
   int sum=result(num1,num2);
    printf("The summation of the math:%d\n",sum);

}
