// Recursive C program to search an element in linked list 
#include<stdio.h> 
#include<stdlib.h> 
#include<stdbool.h> 

struct Node 
{ 
	int data; 
	struct Node* next; 
}; 


void push(struct Node** head_ref, int value) 
{ 
	
	struct Node* new_node = 
			(struct Node*) malloc(sizeof(struct Node)); 

	
	new_node->data = value; 

	
	new_node->next = (*head_ref); 

	
	(*head_ref) = new_node; 
} 

bool search(struct Node* head, int x) 
{ 
	
	if (head == NULL) 
		return false; 
	 
	if (head->data == x) 
		return true; 

	 
	return search(head->next, x); 
} 


int main() 
{ 
	
	struct Node* head = NULL; 
	int x = 21; 

	
	push(&head, 10); 
	push(&head, 30); 
	push(&head, 11); 
	push(&head, 21); 
	push(&head, 14); 

	search(head, 12)? printf("Yes") : printf("No"); 
	return 0; 
} 
