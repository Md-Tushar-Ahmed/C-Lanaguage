#include<stdio.h>
int main()
{
    FILE *file;
    char name[20] = "Tushar Ahmed";
    int length;
    length = strlen(name);
    int i;
    file = fopen("text.txt","w");
    if(file == NULL){
        printf("File doesn't exist\n");
    }
    else{
        printf("File is opened\n");
        for(i=0;i<length;i++){
            fputc(name[i],file);
        }
        printf("File is Written Successfully\n");
        fclose(file);
    }
    return 0;
}
