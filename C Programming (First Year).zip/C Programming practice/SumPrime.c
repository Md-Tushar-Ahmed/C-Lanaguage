#include<stdio.h>
int main()
{
    int n,count,i=3,j,sum=0;
    printf("Enter the number of prime numbers for addition\n");
    scanf("%d",&n);
    if(n>=1)
    {
        printf("First %d prime numbers are:\n",n);
        printf("2 ");
    }
    for(count=2;count<=n;)
    {
       for(j=2;j<=i-1;j++)
       {
           if(i%j==0)
            break;
       }
       if(j==i)
       {
           sum=sum+i;
           printf("%d ",i);
           count++;
       }
       i++;
    }
    printf("\n");
    printf("Sum=%d\n",sum);
    return 0;
}
