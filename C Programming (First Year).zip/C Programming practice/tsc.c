#include<stdio.h>
int main ()
{
    int num;
    printf("Enter the number=");
    scanf("%d",&num);

    if (num>=0)
    {
        printf("The number is possitive");
    }
    else
    {
        printf("The number is negative");
    }
    return 0;
}
