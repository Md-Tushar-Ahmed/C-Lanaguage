#include<stdio.h>
int main ()
{
    int age ;
    printf("Enter the age=");
    scanf("%d",&age);
    if (age>=18)
    {
        printf("You can capable for voting");

    }
    else
    {
        printf("You can not capable for voting");
    }
    return 0;
}
