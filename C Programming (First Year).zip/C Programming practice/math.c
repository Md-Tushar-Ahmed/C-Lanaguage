#include<stdio.h>
#include<math.h>>
int main()
{
    double x=15.3;
    double result =log(x);
    printf("log(%lf) =%lf\n",x,result);
    return 0;
}
