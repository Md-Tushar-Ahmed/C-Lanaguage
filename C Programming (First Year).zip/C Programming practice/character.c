#include<stdio.h>
int main()
{
    int n;
    printf("Enter the ASCII value :");
    scanf("%d",&n);
    printf("Answer the character is=%c",n);
    return 0;
}
